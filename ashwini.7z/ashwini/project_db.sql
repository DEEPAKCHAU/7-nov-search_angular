CREATE DATABASE  IF NOT EXISTS `cybagedb` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `cybagedb`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: cybagedb
-- ------------------------------------------------------
-- Server version	5.7.12-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `test_case`
--

DROP TABLE IF EXISTS `test_case`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test_case` (
  `TestCase_id` int(11) NOT NULL AUTO_INCREMENT,
  `Data_Set` varchar(255) DEFAULT NULL,
  `TestCase_desc` varchar(255) DEFAULT NULL,
  `TestCase_title` varchar(255) DEFAULT NULL,
  `Used_TsetScript` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`TestCase_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_case`
--

LOCK TABLES `test_case` WRITE;
/*!40000 ALTER TABLE `test_case` DISABLE KEYS */;
/*!40000 ALTER TABLE `test_case` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testcasess`
--

DROP TABLE IF EXISTS `testcasess`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `testcasess` (
  `TestCase_id` int(11) NOT NULL AUTO_INCREMENT,
  `data_Set` varchar(255) DEFAULT NULL,
  `testCase_desc` varchar(30) DEFAULT NULL,
  `TestCase_title` varchar(30) DEFAULT NULL,
  `used_TsetScript` varchar(255) DEFAULT NULL,
  `testplan_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`TestCase_id`),
  UNIQUE KEY `UK_aneok9ikt7lemb8x8i2akxvkn` (`TestCase_title`),
  KEY `FK_7mft8swylxl2sawc9an3yifju` (`testplan_id`),
  CONSTRAINT `FK_7mft8swylxl2sawc9an3yifju` FOREIGN KEY (`testplan_id`) REFERENCES `testplan` (`testplan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testcasess`
--

LOCK TABLES `testcasess` WRITE;
/*!40000 ALTER TABLE `testcasess` DISABLE KEYS */;
/*!40000 ALTER TABLE `testcasess` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testexecution`
--

DROP TABLE IF EXISTS `testexecution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `testexecution` (
  `testExcutionId` int(11) NOT NULL AUTO_INCREMENT,
  `testExcutionResult` varchar(255) DEFAULT NULL,
  `testExcutionRunsOn` varchar(255) DEFAULT NULL,
  `testExcutionRunsTestCase` varchar(255) DEFAULT NULL,
  `testExcutionStatus` varchar(255) DEFAULT NULL,
  `testExcutionTitle` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`testExcutionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testexecution`
--

LOCK TABLES `testexecution` WRITE;
/*!40000 ALTER TABLE `testexecution` DISABLE KEYS */;
/*!40000 ALTER TABLE `testexecution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testplan`
--

DROP TABLE IF EXISTS `testplan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `testplan` (
  `testplan_id` int(11) NOT NULL AUTO_INCREMENT,
  `testplan_description` varchar(30) DEFAULT NULL,
  `testplan_status` varchar(30) DEFAULT NULL,
  `testplan_title` varchar(30) DEFAULT NULL,
  `testplan_type` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`testplan_id`),
  UNIQUE KEY `UK_pjs9tvf8wh9juar2bqnrxfs36` (`testplan_title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testplan`
--

LOCK TABLES `testplan` WRITE;
/*!40000 ALTER TABLE `testplan` DISABLE KEYS */;
/*!40000 ALTER TABLE `testplan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testscript`
--

DROP TABLE IF EXISTS `testscript`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `testscript` (
  `testScriptId` int(11) NOT NULL AUTO_INCREMENT,
  `testScriptDataset` varchar(255) DEFAULT NULL,
  `testScriptDescription` varchar(255) DEFAULT NULL,
  `testScriptExecutionInstruction` varchar(255) DEFAULT NULL,
  `testScriptTitle` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`testScriptId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testscript`
--

LOCK TABLES `testscript` WRITE;
/*!40000 ALTER TABLE `testscript` DISABLE KEYS */;
INSERT INTO `testscript` VALUES (1,'f','f','f','f'),(2,'u','o','u','o');
/*!40000 ALTER TABLE `testscript` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-07 18:29:59
